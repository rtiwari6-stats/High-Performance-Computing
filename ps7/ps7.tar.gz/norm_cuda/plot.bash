#!/bin/bash

python3 plot.py cu_norm_0.txt cu_norm_1.txt cu_norm_2.txt cu_norm_3.txt cu_norm_4.txt 
