#!/bin/bash

python3 plot.py cu_axpy_1.txt cu_axpy_2.txt  cu_axpy_3.txt cu_axpy_t.txt  omp_axpy.txt  seq_axpy.txt
