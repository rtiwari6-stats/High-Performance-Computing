

declare -a ALLDEFS=("")
declare -a ALLOPTS=("-fsanitize=address -g -O0 -fno-omit-frame-pointer"  "-Ofast -march=native -DNDEBUG")
